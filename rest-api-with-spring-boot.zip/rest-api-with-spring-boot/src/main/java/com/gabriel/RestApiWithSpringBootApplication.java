package com.gabriel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestApiWithSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestApiWithSpringBootApplication.class, args);
	}

}
