package com.gabriel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestApiWithSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
